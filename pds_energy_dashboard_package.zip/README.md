﻿# Energy Sector Upskilling Dashboard

Open dashboard locally:
file:///C:/Users/guvnl/Downloads/pds_energy_dashboard/index.html

Files:
- index.html: static dashboard code
- data.js: cleaned dataset embedded for browser use
- report.html: printable report version
- PDS_Hackathon_Energy_Upskilling_Report.pdf: submission-ready PDF report
- summary.json: key computed metrics

Public sharing:
1. Upload this folder to GitHub Pages, Netlify Drop, or another static host.
2. Share the generated public URL to index.html.
3. Replace the local dashboard link in the PDF/report with that public URL if your evaluator must access it outside your machine.
